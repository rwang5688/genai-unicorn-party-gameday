pip install --no-cache-dir -r requirements.txt
#sudo yum install -y iproute
sudo apt install -y jq
sudo apt install -y lsof
python3 patient_table.py