Karl the intern here.  I started trying to get this working, but I think they found out I'm not a doctor and I don't know anything about anything.

At any rate, I added a couple scripts to this repo that might help.

You have to run 'sh setup.sh' first to install all the junk.  I don't know if it's all needed but it seems to work.

I couldn't connect to the app, I asked around and someone said 'security group blah blah' then I saw a squirrel and forget.  So you probably need to do something there.

Make sure to fix the TODOs!!! Nothing will work right until you do.

You have to run 'sh run.sh' to start the streamlit app.  It should throw a link up when it's ready.  If you run the app more than once it'll give a new url, but there's some options in streamlit itself to restart and stuff if you make code changes. 



Good luck, sorry for leaving this mess behind.

P.S. there's some good documentation for the pieces I didn't get a chance to finish. 

After cloning this repo in Cloud9 you'll need to open a terminal there to run these commands.